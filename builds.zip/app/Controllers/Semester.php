<?php

namespace App\Controllers;

use App\Controllers\BaseController;

class Semester extends BaseController
{
    public function index()
    {
        //
    }
}
