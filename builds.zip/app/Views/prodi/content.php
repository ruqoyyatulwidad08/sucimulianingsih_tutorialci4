<?php
echo $this->extend('template/index');
echo $this->section('content');
?> 
<p>content mahasiswa</p>
<?php
echo $this->endSection();